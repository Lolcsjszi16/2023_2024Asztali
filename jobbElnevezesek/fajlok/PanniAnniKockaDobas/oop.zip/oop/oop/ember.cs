﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oop
{
    internal class ember
    {
        public string person;
        public int nap;
        public int ho;
        public int ev;
        public string personalityTraits;

    }
}
